from distutils.core import setup

setup(
 name = 'funfunc',
 version = '1.0.0',
 py_modules = ['funfunc'],
 author = 'Kedar',
 author_email = 'ksalunkh@redhat.com',
 description = 'A simple printer of nested lists',

)
